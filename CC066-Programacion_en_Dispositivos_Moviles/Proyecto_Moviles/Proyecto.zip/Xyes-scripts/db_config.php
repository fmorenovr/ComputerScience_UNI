<?php
define('DB_USER', "u588311430_user"); // db user
define('DB_PASSWORD', "123456"); // db password (mention your db password here)
define('DB_DATABASE', "u588311430_ocsm"); // database name
define('DB_SERVER', "localhost"); // db server
?> 