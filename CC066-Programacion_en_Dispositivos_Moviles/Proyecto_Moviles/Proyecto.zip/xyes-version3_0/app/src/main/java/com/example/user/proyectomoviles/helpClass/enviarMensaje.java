package com.example.user.proyectomoviles.helpClass;

/**
 * Created by jbot on 22/02/16.
 */
public interface enviarMensaje {
    void enviarDatos(String ... cadena);
}