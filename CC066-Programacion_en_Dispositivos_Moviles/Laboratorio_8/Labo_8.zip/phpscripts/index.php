<?php

echo "Esto es php"


?>