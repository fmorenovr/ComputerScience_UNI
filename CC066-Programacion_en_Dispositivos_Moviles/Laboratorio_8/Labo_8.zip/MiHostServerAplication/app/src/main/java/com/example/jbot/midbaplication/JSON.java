package com.example.jbot.midbaplication;

import android.widget.TextView;

/**
 * Created by jbot on 28/02/16.
 */
public class JSON {
    public JSON(MainActivity mainActivity, TextView status, TextView role, int i) {
    }

    public void execute(String username, String password) {

    }
}
