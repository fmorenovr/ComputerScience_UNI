package com.example.jbot.miactionbars;

/**
 * Created by jbot on 22/02/16.
 */
public interface enviarMensaje {
    void enviarDatos(String mensaje);
}