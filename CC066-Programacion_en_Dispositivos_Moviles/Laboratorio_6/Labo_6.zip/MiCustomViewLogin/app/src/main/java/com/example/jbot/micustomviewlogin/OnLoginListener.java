package com.example.jbot.micustomviewlogin;

/**
 * Created by jbot on 25/02/16.
 */
public interface OnLoginListener {
    void onLogin(String usuario, String password);
}