package com.example.jbot.milayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // ACTIVIDAD 1
        //setContentView(R.layout.activity_main);

        // ACTIVIDAD 2
        //setContentView(R.layout.activity_segunda);

        // ACTIVIDAD 3
        //setContentView(R.layout.activity_tercera);

        // ACTIVIDAD 4
        setContentView(R.layout.activity_cuarta);

        // ACTIVIDAD 5
        //setContentView(R.layout.activity_quinta);
    }
}
