backgrid-paginator
==================

[![Build Status](https://travis-ci.org/wyuenho/backgrid-paginator.png?branch=master)](https://travis-ci.org/wyuenho/backgrid-paginator)


Dependencies
============

[backbone-pageable](http://github.com/wyuenho/backbone-pageable/)

Usage
====

See the [Paginator](http://backgridjs.com/ref/extensions/paginator.html) section
in the documentation.
