/*

Copyright (C) 2009-2015   Lukas F. Reichlin

This file is part of LTI Syncope.

LTI Syncope is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

LTI Syncope is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with LTI Syncope.  If not, see <http://www.gnu.org/licenses/>.

Invariant zeros of state-space models.
Uses SLICOT AB08ND by courtesy of NICONET e.V.
<http://www.slicot.org>

Author: Lukas Reichlin <lukas.reichlin@gmail.com>
Created: November 2009
Version: 0.8

*/

#include <octave/oct.h>
#include <f77-fcn.h>
#include "common.h"
#include <complex>
#include <xpow.h>

extern "C"
{ 
    int F77_FUNC (ab08nd, AB08ND)
                 (char& EQUIL,
                  octave_idx_type& N, octave_idx_type& M, octave_idx_type& P,
                  const double* A, octave_idx_type& LDA,
                  const double* B, octave_idx_type& LDB,
                  const double* C, octave_idx_type& LDC,
                  const double* D, octave_idx_type& LDD,
                  octave_idx_type& NU, octave_idx_type& RANK, octave_idx_type& DINFZ,
                  octave_idx_type& NKROR, octave_idx_type& NKROL, octave_idx_type* INFZ,
                  octave_idx_type* KRONR, octave_idx_type* KRONL,
                  double* AF, octave_idx_type& LDAF,
                  double* BF, octave_idx_type& LDBF,
                  double& TOL,
                  octave_idx_type* IWORK, double* DWORK, octave_idx_type& LDWORK,
                  octave_idx_type& INFO);
                                   
    int F77_FUNC (dggev, DGGEV)
                 (char& JOBVL, char& JOBVR,
                  octave_idx_type& N,
                  double* AF, octave_idx_type& LDAF,
                  double* BF, octave_idx_type& LDBF,
                  double* ALPHAR, double* ALPHAI,
                  double* BETA,
                  double* VL, octave_idx_type& LDVL,
                  double* VR, octave_idx_type& LDVR,
                  double* WORK, octave_idx_type& LWORK,
                  octave_idx_type& INFO);
}

// PKG_ADD: autoload ("__sl_ab08nd__", "__control_slicot_functions__.oct");    
DEFUN_DLD (__sl_ab08nd__, args, nargout,
   "-*- texinfo -*-\n\
Slicot AB08ND Release 5.0\n\
No argument checking.\n\
For internal use only.")
{
    octave_idx_type nargin = args.length ();
    octave_value_list retval;
    
    if (nargin != 5)
    {
        print_usage ();
    }
    else
    {
        // arguments in
        char equil;
        
        const Matrix a = args(0).matrix_value ();
        const Matrix b = args(1).matrix_value ();
        const Matrix c = args(2).matrix_value ();
        const Matrix d = args(3).matrix_value ();
        const octave_idx_type scaled = args(4).int_value ();
        
        if (scaled == 0)
            equil = 'S';
        else
            equil = 'N';
        
        octave_idx_type n = a.rows ();      // n: number of states
        octave_idx_type m = b.columns ();   // m: number of inputs
        octave_idx_type p = c.rows ();      // p: number of outputs
        
        octave_idx_type lda = max (1, a.rows ());
        octave_idx_type ldb = max (1, b.rows ());
        octave_idx_type ldc = max (1, c.rows ());
        octave_idx_type ldd = max (1, d.rows ());
        
        // arguments out
        octave_idx_type nu;
        octave_idx_type rank;
        octave_idx_type dinfz;
        octave_idx_type nkror;
        octave_idx_type nkrol;
        
        octave_idx_type ldaf = max (1, n + m);
        octave_idx_type ldbf = max (1, n + p);

        OCTAVE_LOCAL_BUFFER (octave_idx_type, infz, n);
        OCTAVE_LOCAL_BUFFER (octave_idx_type, kronr, 1 + max (n, m));
        OCTAVE_LOCAL_BUFFER (octave_idx_type, kronl, 1 + max (n, p));
        
        OCTAVE_LOCAL_BUFFER (double, af, ldaf * (n + min (p, m)));
        OCTAVE_LOCAL_BUFFER (double, bf, ldbf * (n + m));

        // workspace
        octave_idx_type s = max (m, p);
        octave_idx_type ldwork = max (1, max (s, n) + max (3*s-1, n+s));
        
        OCTAVE_LOCAL_BUFFER (octave_idx_type, iwork, s);
        OCTAVE_LOCAL_BUFFER (double, dwork, ldwork);
        
        // error indicator
        octave_idx_type info;
        
        // tolerance
        double tol = 0;     // AB08ND uses DLAMCH for default tolerance

        // SLICOT routine AB08ND
        F77_XFCN (ab08nd, AB08ND,
                 (equil,
                  n, m, p,
                  a.fortran_vec (), lda,
                  b.fortran_vec (), ldb,
                  c.fortran_vec (), ldc,
                  d.fortran_vec (), ldd,
                  nu, rank, dinfz,
                  nkror, nkrol, infz,
                  kronr, kronl,
                  af, ldaf,
                  bf, ldbf,
                  tol,
                  iwork, dwork, ldwork,
                  info));

        if (f77_exception_encountered)
            error ("ss: zero: __sl_ab08nd__: exception in SLICOT subroutine AB08ND");
            
        if (info != 0)
            error ("ss: zero: __sl_ab08nd__: AB08ND returned info = %d", info);
        
        
        // DGGEV Part
        char jobvl = 'N';
        char jobvr = 'N';

        double* vl = 0;     // not referenced because jobvl = 'N'
        octave_idx_type ldvl = 1;
        double* vr = 0;     // not referenced because jobvr = 'N'
        octave_idx_type ldvr = 1;
        
        octave_idx_type lwork = max (1, 8*nu);
        OCTAVE_LOCAL_BUFFER (double, work, lwork);
        
        ColumnVector alphar (nu);
        ColumnVector alphai (nu);
        ColumnVector beta (nu);
        
        octave_idx_type info2;
        
        F77_XFCN (dggev, DGGEV,
                 (jobvl, jobvr,
                  nu,
                  af, ldaf,
                  bf, ldbf,
                  alphar.fortran_vec (), alphai.fortran_vec (),
                  beta.fortran_vec (),
                  vl, ldvl,
                  vr, ldvr,
                  work, lwork,
                  info2));
                                 
        if (f77_exception_encountered)
            error ("ss: zero: __sl_ab08nd__: exception in LAPACK subroutine DGGEV");
            
        if (info2 != 0)
            error ("ss: zero: __sl_ab08nd__: DGGEV returned info = %d", info2);

        // calculate gain
        octave_value gain = Matrix (0, 0);;

        if (m == 1 && p == 1)
        {
            if (nu < n)
                gain = c * xpow (a, double (n-1-nu)).matrix_value() * b;
            else
                gain = d;
        }

        // assemble complex vector - adapted from DEFUN complex in data.cc
        ColumnVector zeror (nu);
        ColumnVector zeroi (nu);

        zeror = quotient (alphar, beta);
        zeroi = quotient (alphai, beta);

        ComplexColumnVector zero (nu, Complex ());

        for (octave_idx_type i = 0; i < nu; i++)
            zero.xelem (i) = Complex (zeror(i), zeroi(i));

        // prepare additional outputs for info struct
        RowVector infzr (dinfz);
        RowVector kronrr (nkror);
        RowVector kronlr (nkrol);
        
        for (octave_idx_type i = 0; i < dinfz; i++)
            infzr.xelem (i) = infz[i];
        
        for (octave_idx_type i = 0; i < nkror; i++)
            kronrr.xelem (i) = kronr[i];
        
        for (octave_idx_type i = 0; i < nkrol; i++)
            kronlr.xelem (i) = kronl[i];

        // return values
        retval(0) = zero;
        retval(1) = gain;
        retval(2) = octave_value (rank);
        retval(3) = infzr;
        retval(4) = kronrr;
        retval(5) = kronlr;
    }
    
    return retval;
}
