package tarea_grafica;
import javax.swing.JFrame;

public class Ventana extends JFrame {
    Lienzo panel;
    
    public Ventana(String nombre){
        super(nombre);
        panel=new Lienzo();
        add(panel);
        setSize(1100,750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
                }
    }
