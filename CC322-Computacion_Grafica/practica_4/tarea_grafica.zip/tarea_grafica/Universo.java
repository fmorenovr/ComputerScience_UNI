package tarea_grafica;
/*
 @author georgeprado
 */
public class Universo {
    
    public static void main(String[] args)throws InterruptedException {
        Ventana windows = new Ventana("Via Lactea");
	windows.setVisible(true);
        while(true){
        windows.panel.move();
        windows.panel.repaint();
        Thread.sleep(60);
            }
    }
    
}
//